#ifndef aloha_aux_functions_guard
#define aloha_aux_functions_guard
double Sgn(double e,double f);
#endif
